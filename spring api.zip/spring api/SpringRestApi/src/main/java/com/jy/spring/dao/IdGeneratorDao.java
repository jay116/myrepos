package com.jy.spring.dao;


public interface IdGeneratorDao {
	
	public int doIncrementWithLock() ;

}
